-- Insert categories into the Categories table
INSERT INTO Categories (name, priority_level) VALUES ('Smartphones', 1);
INSERT INTO Categories (name, priority_level) VALUES ('Laptops', 2);
INSERT INTO Categories (name, priority_level) VALUES ('Gaming Consoles', 3);
INSERT INTO Categories (name, priority_level) VALUES ('Virtual Reality', 4);
INSERT INTO Categories (name, priority_level) VALUES ('Drones', 5);
INSERT INTO Categories (name, priority_level) VALUES ('AI Assistants', 6);
INSERT INTO Categories (name, priority_level) VALUES ('Holographic Devices', 7);
INSERT INTO Categories (name, priority_level) VALUES ('Wearable Tech', 8);