-- Insert products into the Products table
INSERT INTO Products (name, description, image_url, price, category_id, is_featured) 
VALUES ('CyberPhone X', 'A futuristic smartphone with holographic display.', 'images/placeholder.jpg', 999.99, 1, 0);

INSERT INTO Products (name, description, image_url, price, category_id, is_featured) 
VALUES ('Quantum Laptop', 'A laptop powered by quantum computing.', 'images/placeholder.jpg', 2499.99, 2, 0);
