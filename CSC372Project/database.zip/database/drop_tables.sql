-- Drop CartProducts table
DROP TABLE IF EXISTS CartProducts;

-- Drop Carts table
DROP TABLE IF EXISTS Carts;

-- Drop Products table
DROP TABLE IF EXISTS Products;

-- Drop Categories table
DROP TABLE IF EXISTS Categories;

-- Drop Users table
DROP TABLE IF EXISTS Users;